import React, { useState } from "react";
import DynamicPosts from "../DynamicPosts/DynamicPosts";

import "./Banner.css";

function Banner() {
  let [category, setCategory] = useState();
  
  return (
    <div className="bannerParentDiv">
      <div className="bannerChildDiv">
        <div className="menuBar">
          <div className="categoryMenu">
            <select
              name="Category"
              onChange={(e) => {
                setCategory(e.target.value);
              }}
            >
              {" "}
              <option value="null">All Categories Of Tools</option>
              <option value="Cars">Tractor</option>
              <option value="Cameras & Lenses">Spade&Shovel</option>
              <option value="Computers & Laptops">Power Weeder</option>
              <option value="Mobile Phones">Sprayer</option>
              <option value="Motorcycle">Seed Driller</option>
              <option value="Tablets">Hand Cultivator</option>
              <option value="Tablets">Sprayer</option>
              <option value="Tablets">TeerPal</option>
            </select>
          </div>
          <div className="otherQuickOptions">
            <span onClick={()=>setCategory("Tractor")} >Tractor</span>
            <span onClick={()=>setCategory("Spade&Shovel")} >Spade&Shovel</span>
            <span onClick={()=>setCategory("Power Weeder")} >Power Weeder</span>
            <span onClick={()=>setCategory("Sprayer")} >Sprayer</span>
            <span onClick={()=>setCategory("Seed Driller")} >Seed Driller</span>
            <span onClick={()=>setCategory("Hand Cultivator")} >Hand Cultivator</span>
            <span onClick={()=>setCategory("Sprayer")} >Sprayer</span>
            <span onClick={()=>setCategory("TeerPal")} >TeerPal</span>


          </div>
        </div>
        <div className="banner">
          <img object-fit="cover" width="100%" height="250px"src="https://tse3.mm.bing.net/th?id=OIP.MZLQMA0Q3slNu9wbEAgvwAHaDt&pid=Api&P=0&w=383&h=191" alt="" />
        </div>
      </div>
     { category!=null && <DynamicPosts category={category}/>  }
    </div>
  );
}

export default Banner;
