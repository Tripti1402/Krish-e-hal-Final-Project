import React, { useState } from "react";
import DynamicPosts from "../DynamicPosts/DynamicPosts";

import "./Banner.css";

function Banner() {
  let [category, setCategory] = useState();
  
  return (
    <div className="bannerParentDiv">
      <div className="bannerChildDiv">
        <div className="menuBar">
          <div className="categoryMenu">
            <select
              name="Category"
              onChange={(e) => {
                setCategory(e.target.value);
              }}
            >
              {" "}
              <option value="null">उपकरण की सभी श्रेणियाँ</option>
              <option value="Tractor">ट्रैक्टर</option>
              <option value="Spade&Shovel">फावडा&बेलचा</option>
              <option value="Power Weeder">पावर वीडर</option>
              <option value="Sprayer">स्प्रेयर</option>
              <option value="Seed Driller">बीज ड्रिलर</option>
              <option value="Hand Cultivator">हाथ कृषक</option>
              <option value="TeerPal">तीरपाल</option>
            </select>
          </div>
          <div className="otherQuickOptions">
            <span onClick={()=>setCategory("Tractor")} >ट्रैक्टर</span>
            <span onClick={()=>setCategory("Spade&Shovel")} >फावडा&बेलचा</span>
            <span onClick={()=>setCategory("Power Weeder")} >पावर वीडर</span>
            <span onClick={()=>setCategory("Sprayer")} >स्प्रेयर</span>
            <span onClick={()=>setCategory("Seed Driller")} >बीज ड्रिलर</span>
            <span onClick={()=>setCategory("Hand Cultivator")} >हाथ कृषक</span>
            <span onClick={()=>setCategory("TeerPal")} >तीरपाल</span>


          </div>
        </div>
        <div className="banner">
          <img object-fit="cover" width="100%" height="250px"src="https://tse3.mm.bing.net/th?id=OIP.MZLQMA0Q3slNu9wbEAgvwAHaDt&pid=Api&P=0&w=383&h=191" alt="" />
        </div>
      </div>
     { category!=null && <DynamicPosts category={category}/>  }
    </div>
  );
}

export default Banner;
