import firebase from 'firebase/compat/app'
import 'firebase/compat/auth'
import 'firebase/compat/firestore'
import 'firebase/compat/storage'
const firebaseConfig = {
  apiKey: "AIzaSyD2Nq1o5Fz5Mnf9svsuXhZNQlZDzid5vRE",
  authDomain: "krishehl-84aa1.firebaseapp.com",
  databaseURL: "https://krishehl-84aa1-default-rtdb.firebaseio.com",
  projectId: "krishehl-84aa1",
  storageBucket: "krishehl-84aa1.appspot.com",
  messagingSenderId: "1061722709625",
  appId: "1:1061722709625:web:98202355fc60df1b15bea8",
  measurementId: "G-X3SXCTSVHD"
};

  export const Firebase= firebase.initializeApp(firebaseConfig)//named export